#!/bin/bash

# License settings to be done in ~/.bashrc or ~/.cshrc
# 8.1 Version ENCOUNTER.

encounter -init ../scripts/power.tcl -log ../logs/power.log

