#!/bin/bash

\rm -rf ./work
vsim -do simulate.do
