#!/bin/bash 





# License settings to be done in ~/.bashrc or ~/.cshrc
# 8.1 Version ENCOUNTER.

${SoC_tool} -init ../scripts/pnr.tcl -log ../logs/pnr.log

