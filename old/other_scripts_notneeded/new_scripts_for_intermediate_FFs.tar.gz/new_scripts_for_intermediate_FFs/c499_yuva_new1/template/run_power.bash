#!/bin/bash



# License settings to be done in ~/.bashrc or ~/.cshrc
# 8.1 Version ENCOUNTER.

${SoC_Tool} -init ../scripts/power.tcl -log ../logs/power.log

