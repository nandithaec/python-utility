#!/bin/bash



${VSIM_tool} -do simulate.do
